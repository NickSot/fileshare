package org.tues.fileshare;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FileshareApplicationTests {

	@Test
	void contextLoads() {
	}

}
